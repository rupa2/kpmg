﻿
function GetValue($object, $key)
{
    $p1,$p2 = $key.Split("/")
    if($p2) { return GetValue -object $object.$p1 -key $p2 }
    else { return $object.$p1 }
}


$Obj = ConvertFrom-Json '{ "a": {"b" :{"c": "d"} }}'
$key = " "


while( $key -ne "exit"){
$key = Read-Host "Please enter key - a or a/b or a/b/c or enter exit to leave the console"
    if ($key -ne "exit")
    {
    $value = GetValue -object $Obj -key $Key
    Write-output " Value of $key : $value"
    }
    else
    {
    Write-output " Exit.. the console"
    }
}